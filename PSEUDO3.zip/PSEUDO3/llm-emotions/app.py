from flask import Flask, render_template, request, jsonify
from ollama import Client
import json

app = Flask(__name__)
client = Client()

MATRIX_SIZE = 10

error = r"""  File "C:\Users\Usuario\PycharmProjects\LLMs\PSEUDO\llm-emotions\app.py", line 31, in generate_light_matrix
    matrix = json.loads(response['message']['content'])
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "C:\Users\Usuario\AppData\Local\Programs\Python\Python312\Lib\json\__init__.py", line 346, in loads
    return _default_decoder.decode(s)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "C:\Users\Usuario\AppData\Local\Programs\Python\Python312\Lib\json\decoder.py", line 337, in decode
    obj, end = self.raw_decode(s, idx=_w(s, 0).end())
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "C:\Users\Usuario\AppData\Local\Programs\Python\Python312\Lib\json\decoder.py", line 355, in raw_decode
    raise JSONDecodeError("Expecting value", s, err.value) from None
json.decoder.JSONDecodeError: Expecting value: line 1 column 1 (char 0)"""
def generate_light_matrix(prompt):
    system_prompt = f"""Eres un sistema de control de una matriz de luces de {MATRIX_SIZE}x{MATRIX_SIZE}.
    Tu tarea es interpretar una descripción de emoción y generar una configuración de luces que la represente.
    Debes devolver una matriz JSON de {MATRIX_SIZE}x{MATRIX_SIZE} donde cada celda es un color en formato hexadecimal.
    
    Revisa de evitar tener este error siempre: {error}
    Revisa siempre cuidadosamente el JSON que este bien formado
    
    Ejemplos de comandos:
    - "todo rojo": Llena toda la matriz con #FF0000
    - "azul en el centro": Coloca #0000FF en el centro y deja el resto en #000000
    - "patrón de felicidad": Usa colores brillantes como #FFFF00 (amarillo) y #FFA500 (naranja) en un patrón alegre
    - "tristeza": Usa tonos de azul como #4682B4 (azul acero) y #1E90FF (azul dodger) en un patrón sombrío

    Responde solo con la matriz JSON, sin explicaciones adicionales.
    # Es muy importante que revises cuidadosamente de que el JSON este bien parseado sino la aplicacion dara error."""

    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": prompt}
    ]

    response = client.chat(model="gemma2", messages=messages)
    matrix = json.loads(response['message']['content'])
    return matrix


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/generate', methods=['POST'])
def generate():
    prompt = request.json['prompt']
    matrix = generate_light_matrix(prompt)
    return jsonify(matrix=matrix)


if __name__ == '__main__':
    app.run(debug=True)