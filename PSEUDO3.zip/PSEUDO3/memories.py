from flask import Flask, render_template_string
import sqlite3

app = Flask(__name__)

# HTML template
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Memorias Almacenadas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #2c3e50;
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            background-color: #f2f2f2;
            margin-bottom: 10px;
            padding: 10px;
            border-radius: 5px;
        }
        .timestamp {
            font-size: 0.8em;
            color: #7f8c8d;
        }
    </style>
</head>
<body>
    <h1>Memorias Almacenadas</h1>
    <ul>
    {% for memoria in memorias %}
        <li>
            <div>{{ memoria[1] }}</div>
            <div class="timestamp">Creado: {{ memoria[2] }}</div>
        </li>
    {% endfor %}
    </ul>
</body>
</html>
"""

@app.route('/')
def mostrar_memorias():
    conn = sqlite3.connect('memorias.db')
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM memorias ORDER BY fecha_creacion DESC")
    memorias = cursor.fetchall()
    conn.close()
    return render_template_string(HTML_TEMPLATE, memorias=memorias)

if __name__ == '__main__':
    app.run(debug=True, port=5001)