import sqlite3
import re
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from datetime import datetime

def limpiar_y_deduplicar_base_de_datos(threshold=0.95):
    model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

    conn = sqlite3.connect('memorias.db')
    cursor = conn.cursor()

    cursor.execute("SELECT id, contenido, fecha_creacion FROM memorias")
    memorias = cursor.fetchall()

    memorias_limpias = []
    duplicados_eliminados = 0

    for id, contenido, fecha_creacion in memorias:
        match = re.search(r'^(.*?)\)\$', contenido)
        if match:
            contenido_limpio = match.group(1)
            fecha = datetime.strptime(fecha_creacion, "%Y-%m-%d %H:%M:%S")
            contenido_formateado = f"{fecha.strftime('%Y-%m-%d %H:%M:%S')} Memoria: {contenido_limpio}"
            memorias_limpias.append((id, contenido_formateado))
        else:
            print(f"No se encontró patrón para limpiar en la memoria con ID {id}")

    textos = [m[1] for m in memorias_limpias]
    embeddings = model.encode(textos)

    memorias_unicas = []
    for i, (id, texto) in enumerate(memorias_limpias):
        es_duplicado = False
        for j, (id_unico, _) in enumerate(memorias_unicas):
            similarity = cosine_similarity([embeddings[i]], [embeddings[memorias_limpias.index((id_unico, _))]])[0][0]
            if similarity > threshold:
                es_duplicado = True
                duplicados_eliminados += 1
                break
        if not es_duplicado:
            memorias_unicas.append((id, texto))

    cursor.execute("DELETE FROM memorias")

    for id, contenido in memorias_unicas:
        cursor.execute("INSERT INTO memorias (id, contenido) VALUES (?, ?)", (id, contenido))

    cursor.execute("DELETE FROM sqlite_sequence WHERE name='memorias'")

    conn.commit()
    conn.close()

    print(f"Limpieza de la base de datos completada. Se eliminaron {duplicados_eliminados} duplicados.")

if __name__ == "__main__":
    limpiar_y_deduplicar_base_de_datos(threshold=0.95)