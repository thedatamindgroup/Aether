$(document).ready(function () {
    var chatHistory = [];

 function formatMessage(text) {
        text = text.replace(/\\n/g, '\n');
        text = preprocessMarkdown(text);
        var markedOptions = {
            breaks: true,
            gfm: true
        };
        text = marked.parse(text, markedOptions);
        return text;
    }

    function preprocessMarkdown(content) {
        content = content.replace(/\*\*\*(.*?)\*\*\*/g, '<strong><em>$1</em></strong>');
        content = content.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
        content = content.replace(/(?<!\*)\*(?!\*)([^*\n]+?)(?<!\*)\*(?!\*)/g, '<em>$1</em>');
        content = content.replace(/(^|\n)(#+)([^ #])/g, '$1$2 $3');
        content = content.replace(/(^|\n)([*-+]\s*)([^:\n]+):(\s*)/g, '$1$2$3:$4');
        content = content.replace(/(^|\n)[*-+](?=[^\s])/g, '$& ');
        content = content.replace(/(?<!\n)\n(?!\n)/g, '\n\n');
        content = content.replace(/(\n|^)([^\n]+)\n(#+ )/g, '$1$2\n\n$3');
        content = content.replace(/(\n\s*[-*+]\s+[^\n]+)(\n\s+)/g, '$1\n$2');
        content = content.replace(/(\n|^)([^\n]+)\n([-*])/g, '$1$2\n\n$3');
        content = content.replace(/(\n|^)([^\n]*\|[^\n]*\n)([^\n]*\|-*\|[^\n]*\n(?:[^\n]*\|[^\n]*\n)*)/g, '\n$1$2$3\n');
        content = content.replace(/(\|)\s*([^|]+?)\s*(?=\|)/g, '$1 $2 ');
        return content;
    }

    function addMessage(message, isUser) {
        var messageClass = isUser ? 'user-message' : 'bot-message';
        var avatar = isUser ? '👤' : '🤖';
        var content = isUser ? message : formatMessage(message);
        $('#chat-box').append(
            '<div class="message ' + messageClass + '">' +
            '<span class="message-content">' + avatar + ' ' + content + '</span>' +
            '</div>'
        );
        $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
    }

    $('#chat-form').submit(function (e) {
        e.preventDefault();
        var userMessage = $('#user-input').val();
        if (userMessage.trim() === '') return;
        addMessage(userMessage, true);
        chatHistory.push({ role: "user", content: userMessage });

        $('#user-input').prop('disabled', true);
        $('#send-button .send-icon').hide();
        $('#send-button .typing-indicator').show();

        $.ajax({
            url: '/start_chat',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ message: userMessage }),
            success: function () {
                var eventSource = new EventSource('/stream_chat');
                var botMessage = "";
                addMessage('', false);
                eventSource.onmessage = function (event) {
                    if (event.data === "[DONE]") {
                        chatHistory.push({ role: "assistant", content: botMessage.trim() });
                        eventSource.close();

                        $('#user-input').prop('disabled', false);
                        $('#send-button .typing-indicator').hide();
                        $('#send-button .send-icon').show();
                    } else {
                        botMessage += event.data;
                        $('#chat-box .bot-message:last .message-content').html('🤖 ' + formatMessage(botMessage));
                    }
                    $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);
                };
                eventSource.onerror = function () {
                    eventSource.close();

                    $('#user-input').prop('disabled', false);
                    $('#send-button .typing-indicator').hide();
                    $('#send-button .send-icon').show();
                };
            }
        });

        $('#user-input').val('').focus();
    });
});